<template>
  <div class="fly-panel">
    <div class="fly-panel-title">在线课程</div>
    <div class="fly-panel-main">
      <a href="https://class.imooc.com/sale/webfullstack?mc_marking=1eb5ce0be2ada8da4a6387b391f00b92&mc_channel=syzcjj1" target="_blank" class="fly-zanzhu" style="background-color: #5FB878;">大前端-更高层面进阶前端</a>
      <a href="https://www.imooc.com/learn/1091" target="_blank" class="fly-zanzhu" style="background-color: #5FB878;">3小时速成 Vue2.x 核心技术</a>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'ads'
})
</script>

<style lang="scss" scoped>
</style>
