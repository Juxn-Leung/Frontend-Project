export const textMap: { [key: string]: string } = {
  share: '分享',
  ask: '提问',
  advise: '建议',
  logs: '动态',
  discuss: '交流',
  notice: '公告'
}
