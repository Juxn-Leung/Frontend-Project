## 1.1.0（2021-04-16）
- 修复 uni-rate 属性 margin 值为 string 组件失效的 bug
## 1.0.9（2021-02-05）
- 优化 组件引用关系，通过uni_modules引用组件
## 1.0.8（2021-02-05）
- 调整为uni_modules目录规范
- 支持 pc 端
