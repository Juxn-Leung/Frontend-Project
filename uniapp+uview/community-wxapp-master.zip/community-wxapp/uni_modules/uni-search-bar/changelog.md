## 1.0.7（2021-04-15）
- uni-ui 新增 uni-search-bar 的 focus 事件
## 1.0.6（2021-02-05）
- 优化 组件引用关系，通过uni_modules引用组件

## 1.0.5（2021-02-05）
- 调整为uni_modules目录规范
- 新增 支持双向绑定
- 更改 input 事件的返回值，e={value:Number} --> e=value
- 新增 支持图标插槽
- 新增 支持 clear、blur 事件
- 新增 支持 focus 属性
- 去掉组件背景色
