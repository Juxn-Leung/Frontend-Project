import Vue from 'vue';
import Vuex from 'vuex';
// import createLogger from 'vuex/dist/logger'

const debug = process.env.NODE_ENV === 'development';

Vue.use(Vuex);

const state = {
  token: uni.getStorageSync('token') || '',
  userInfo: uni.getStorageSync('userInfo') || {},
  wxInfo: {},
  countInfo: {},
  type: 'comment',
  tab: '',
  code: '',
  // lastPath: {
  //   path: 'pages/home/home',
  //   query: {}
  // }
};

const mutations = {
  setToken(state, value) {
    state.token = value;
    uni.setStorageSync('token', value);
  },
  // 设置用户的基本信息
  setUserInfo(state, value) {
    if (value === '') return;
    state.userInfo = value;
    // 本地存储用户的基本信
    uni.setStorageSync('userInfo', value);
  },
  setWxInfo(state, value) {
    state.wxInfo = value;
  },
  setCountInfo(state, value) {
    state.countInfo = value;
  },
  setType(state, value) {
    state.type = value || 'comment';
  },
  setTab(state, value) {
    state.tab = value || '';
  },
  setCode(state, value) {
    state.code = value || '';
  },
  // setLastPath (state, value) {
  //   console.log('🚀 ~ file: index.js ~ line 35 ~ setLastPath ~ value', value)
  //   state.lastPath = value
  // }
};

const actions = {
  logout({ commit }) {
    commit('setToken', '');
    commit('setUserInfo', {});
    commit('setWxInfo', {});
    commit('setCountInfo', {});
    commit('setType');
    uni.clearStorage();
  },
  // 全局获取Code授权码
  async getNewCode({ commit }) {
    const [err, { code }] = await uni.login();
    if (err) {
      uni.showToast({
        title: '获取授权码失败，请刷新重试',
        duration: 2000,
        icon: 'none',
      });
      return;
    }
    // this.code = code
    commit('setCode', code);
  },
};

const getters = {
  isLogin: (state) => typeof state.userInfo._id !== 'undefined',
};

const store = new Vuex.Store({
  state,
  mutations,
  actions,
  getters,
  plugins: debug ? [Vuex.createLogger()] : [], // 调试模式加入日志插件
});

export default store;
