export const baseUrl = process.env.NODE_ENV === 'development' ? 'http://192.168.31.132:3000' : 'https://yourdomain.com'
