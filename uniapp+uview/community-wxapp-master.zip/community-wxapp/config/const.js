export const tabs = [
  {
    key: '',
    value: '首页'
  },
  {
    key: 'ask',
    value: '提问'
  },
  {
    key: 'share',
    value: '分享'
  },
  {
    key: 'discuss',
    value: '讨论'
  },
  {
    key: 'advise',
    value: '建议'
  },
  {
    key: 'notice',
    value: '公告'
  },
  {
    key: 'logs',
    value: '动态'
  }
]
