export function os() {
	return uni.getSystemInfoSync().platform;
};

export function sys() {
	return uni.getSystemInfoSync();
}


