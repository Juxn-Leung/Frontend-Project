function bem(name, conf) {
  
}

module.exports.bem = bem;
