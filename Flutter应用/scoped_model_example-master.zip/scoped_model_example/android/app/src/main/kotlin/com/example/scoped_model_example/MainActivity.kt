package com.example.scoped_model_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
