import 'package:flutter/material.dart';

class MsgPage extends StatelessWidget {
  const MsgPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
