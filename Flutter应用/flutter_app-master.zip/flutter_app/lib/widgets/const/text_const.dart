import 'package:flutter/material.dart';

final TextStyle availableStyle = TextStyle(
  fontSize: 14.0,
  color: Color(0xFF333333),
  fontWeight: FontWeight.w400,
);

final TextStyle unAvailableStyle = TextStyle(
  fontSize: 14.0,
  color: Colors.black12,
);
