class RegParttern {
  static const mobileParttern = r'^1[3-9]\d{9}$';
  static const codeParttern = r'\d{6}$';
}
