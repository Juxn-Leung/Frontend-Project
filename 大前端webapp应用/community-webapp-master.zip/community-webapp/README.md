# toimc-webapp

## 项目介绍

项目为社区项目的webApp端应用！



目前最新的master分支上的代码为课程视频同步的代码，后续的代码会通过校验的方式进行获取。



## 项目依赖安装

```
npm install
```

### 运行
```
npm run serve
```

### 构建
```
npm run build
```

### 格式化代码
```
npm run lint
```

### 更多自定义设置
参考： [Configuration Reference](https://cli.vuejs.org/config/).
