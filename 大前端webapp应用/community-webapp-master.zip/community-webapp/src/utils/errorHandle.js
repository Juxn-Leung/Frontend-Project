/* eslint-disable handle-callback-err */
const errorHandle = (err) => {
}

export default errorHandle
