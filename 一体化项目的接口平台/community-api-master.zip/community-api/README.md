# window 10
安装：cnpm install
启动：cnpm start