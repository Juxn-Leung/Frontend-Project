// 微信相关
const wxappSecret = {
  appid: process.env.WX_APPID,
  secret: process.env.WX_SECRET
}

export default {
  wxappSecret
}
