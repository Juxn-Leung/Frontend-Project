import draggable from './module/draggable'
import clipboard from './module/clipboard'

const directives = {
  draggable,
  clipboard
}

export default directives
