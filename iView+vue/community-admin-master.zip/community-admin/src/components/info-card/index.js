import InforCard from './infor-card.vue'
export default InforCard
