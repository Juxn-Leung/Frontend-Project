module.exports = function(ctx){
    ctx.body = {
        "message": "hello from b"
    }
}